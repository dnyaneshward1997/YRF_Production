package com.cdac.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="actor_table")
public class Actor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long actorId;

	@Column(nullable = false, length = 50)
	private String actorName;

	@Column(nullable = false, length = 45)
	private String email;

	@Column(nullable = false)
	private String password;

	@Column(nullable = false)
	private String actorIndustry;

	@Column(nullable = false)
	private String gender;

	@Column(nullable = false, length = 4)
	private long actorFees;

	@Column(nullable = false, length = 10)
	private long contact;

	@Column(nullable = false)
	private int isVerified;

	// @OneToMany
	// @JoinColumn(name="actorId")
	@OneToMany(cascade = CascadeType.ALL)
	private List<Appointment> appointmentList = new ArrayList<Appointment>();

	public Actor() {

	}

	public Actor(Long actorId) {
		super();
		this.actorId = actorId;

	}

	public Actor(String actorName, String email, String password, String actorIndustry, String gender,
			long actorFees, long contact, int isVerified) {
		super();
		this.actorName = actorName;
		this.email = email;
		this.password = password;
		this.actorIndustry = actorIndustry;
		this.gender = gender;
		this.actorFees = actorFees;
		this.contact = contact;
		this.isVerified = isVerified;
	}

	public Actor(Long actorId, String actorName, String email, String password, String actorIndustry,
			String gender, long actorFees, long contact, int isVerified) {
		super();
		this.actorId = actorId;
		this.actorName = actorName;
		this.email = email;
		this.password = password;
		this.actorIndustry = actorIndustry;
		this.gender = gender;
		this.actorFees = actorFees;
		this.contact = contact;
		this.isVerified = isVerified;
	}

	public Long getActorId() {
		return actorId;
	}

	public void setActorId(Long actorId) {
		this.actorId = actorId;
	}

	public String getActorName() {
		return actorName;
	}

	public void setActorName(String actorName) {
		this.actorName = actorName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getActorIndustry() {
		return actorIndustry;
	}

	public void setActorIndustry(String actorIndustry) {
		this.actorIndustry = actorIndustry;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public long getActorFees() {
		return actorFees;
	}

	public void setActorFees(long actorFees) {
		this.actorFees = actorFees;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public int getIsVerified() {
		return isVerified;
	}

	public void setIsVerified(int isVerified) {
		this.isVerified = isVerified;
	}

	

	public List<Appointment> getAppointmentList() {
		return appointmentList;
	}

	public void setAppointmentList(List<Appointment> appointmentList) {
		this.appointmentList = appointmentList;
	}

	@Override
	public String toString() {
		return "Actor [actorId=" + actorId + ", actorName=" + actorName + ", email=" + email + ", password=" + password
				+ ", actorIndustry=" + actorIndustry + ", actorGender=" + gender + ", actorFees=" + actorFees
				+ ", actorContact=" + contact + ", isVerified=" + isVerified + "]";
	}

}
