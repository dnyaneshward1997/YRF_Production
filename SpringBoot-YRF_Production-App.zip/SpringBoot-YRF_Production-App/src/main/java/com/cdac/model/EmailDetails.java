package com.cdac.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "emailDetails_table")
public class EmailDetails {

	// class parameters
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long emailIdId;
	private String recipient;
	private String msgBody;
	private String subject;

	public EmailDetails() {

	}

	public EmailDetails(Long emailIdId) {
		super();
		this.emailIdId = emailIdId;

	}

	public EmailDetails(String recipient, String msgBody, String subject) {
		super();
		this.recipient = recipient;
		this.msgBody = msgBody;
		this.subject = subject;
	}

	public EmailDetails(Long emailIdId, String recipient, String msgBody, String subject) {
		super();
		this.emailIdId = emailIdId;
		this.recipient = recipient;
		this.msgBody = msgBody;
		this.subject = subject;
	}

	public Long getEmailIdId() {
		return emailIdId;
	}

	public void setEmailIdId(Long emailIdId) {
		this.emailIdId = emailIdId;
	}

	public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}

	public String getMsgBody() {
		return msgBody;
	}

	public void setMsgBody(String msgBody) {
		this.msgBody = msgBody;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	@Override
	public String toString() {
		return "EmailDetails [emailIdId=" + emailIdId + ", recipient=" + recipient + ", msgBody=" + msgBody
				+ ", subject=" + subject + "]";
	}

}
