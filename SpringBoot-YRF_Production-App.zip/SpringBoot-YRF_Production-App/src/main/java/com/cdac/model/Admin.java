package com.cdac.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin_table")
public class Admin {

	// class parameters
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long adminId;

	@Column(nullable = false, length = 45)
	private String adminName;

	@Column(nullable = false, unique = true, length = 45)
	private String email;

	@Column(unique = true, nullable = false, length = 25)
	private String contact;

	@Column(nullable = false)
	private String password;

	// class constructors
	public Admin() {

	}

	public Admin(Long adminId) {
		super();
		this.adminId = adminId;

	}

	public Admin(String adminName, String email, String contact, String password) {
		super();
		this.adminName = adminName;
		this.email = email;
		this.contact = contact;
		this.password = password;
	}

	public Admin(Long adminId, String adminName, String email, String contact, String password) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.email = email;
		this.contact = contact;
		this.password = password;
	}

	// getters and setters
	public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	// toString
	@Override
	public String toString() {
		return "Admin [AdminId=" + adminId + ", adminName=" + adminName + ", email=" + email + ", contact=" + contact
				+ ", password=" + password + "]";
	}

}
