package com.cdac.model;

import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "appointment_table")
public class Appointment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long appointmentId;

	@Column(nullable = false, length = 50)
	private Date appointmentDate;

	@Column(nullable = false, length = 50)
	private String actorEmail;

	@Column(nullable = false, length = 50)
	private String directorEmail;

	@Column(nullable = false)
	private int timeSlot;

	@Column(nullable = false)
	private int status;

	@Column(nullable = false, length = 50)
	private String actorIndustry;

	@ManyToOne
	private Actor actor;

	@ManyToOne
	private Director director;

	public Appointment() {

	}

	public Appointment(Long appointmentId) {
		super();
		this.appointmentId = appointmentId;

	}

	public Appointment(Date appointmentDate, String actorEmail, String directorEmail, int timeSlot, int status,
			String actorIndustry) {
		super();
		this.appointmentDate = appointmentDate;
		this.actorEmail = actorEmail;
		this.directorEmail = directorEmail;
		this.timeSlot = timeSlot;
		this.status = status;
		this.actorIndustry = actorIndustry;
	}

	public Appointment(Long appointmentId, Date appointmentDate, String actorEmail, String directorEmail, int timeSlot,
			int status, String actorIndustry) {
		super();
		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.actorEmail = actorEmail;
		this.directorEmail = directorEmail;
		this.timeSlot = timeSlot;
		this.status = status;
		this.actorIndustry = actorIndustry;
	}

	public Long getAppointId() {
		return appointmentId;
	}

	public void setAppointmentId(Long appointmentId) {
		this.appointmentId = appointmentId;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getActorEmail() {
		return actorEmail;
	}

	public void setActorEmail(String actorEmail) {
		this.actorEmail = actorEmail;
	}

	public String getDirectorEmail() {
		return directorEmail;
	}

	public void setDirectorEmail(String directorEmail) {
		this.directorEmail = directorEmail;
	}

	public int getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(int timeSlot) {
		this.timeSlot = timeSlot;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getActorIndustry() {
		return actorIndustry;
	}

	public void setActorIndustry(String actorIndustry) {
		this.actorIndustry = actorIndustry;
	}

	public Actor getActor() {
		return actor;
	}

	public void setActor(Actor actor) {
		this.actor = actor;
	}

	public Director getDirector() {
		return director;
	}

	public void setDirector(Director director) {
		this.director = director;
	}

	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", appointmentDate=" + appointmentDate + ", actorEmail="
				+ actorEmail + ", directorEmail=" + directorEmail + ", timeSlot=" + timeSlot + ", status=" + status
				+ ", actorIndustry=" + actorIndustry + "]";
	}

}
