package com.cdac.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "director_table")
public class Director {

	// To show that this is primary id
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long directorId;

	@Column(name = "firstname", nullable = false, length = 50)
	private String firstName;

	@Column(name = "lastname", nullable = false, length = 50)
	private String lastName;

	@Column(name = "address", nullable = false, length = 255)
	private String address;

	@Column(name = "gender", nullable = false, length = 10)
	private String gender;

	@Column(nullable = false, length = 45)
	private String email;

	@Column(nullable = false)
	private String password;

	@Column(name = "contact", nullable = false, length = 25)
	private String contact;

	@Column(nullable = false)
	private Date date;

	@Column(nullable = false)
	private boolean isVerified;

	// @OneToMany
	// @JoinColumn(name="actorId")
	@OneToMany(cascade = CascadeType.ALL)
	private List<Appointment> appointmentList = new ArrayList<Appointment>();

	public Director() {

	}

	public Director(Long directorId) {
		super();
		this.directorId = directorId;

	}

	public Director(String firstName, String lastName, String address, String gender, String email, String password,
			String contact, Date date, boolean isVerified) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.gender = gender;
		this.email = email;
		this.password = password;
		this.contact = contact;
		this.date = date;
		this.isVerified = isVerified;
	}

	public Director(Long directorId, String firstName, String lastName, String address, String gender, String email,
			String password, String contact, Date date, boolean isVerified) {
		super();
		this.directorId = directorId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.gender = gender;
		this.email = email;
		this.password = password;
		this.contact = contact;
		this.date = date;
		this.isVerified = isVerified;
	}

	public Long getDirectorId() {
		return directorId;
	}

	public void setDirectorId(Long directorId) {
		this.directorId = directorId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public boolean isVerified() {
		return isVerified;
	}

	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}

	public List<Appointment> getAppointmentList() {
		return appointmentList;
	}

	public void setAppointmentList(List<Appointment> appointmentList) {
		this.appointmentList = appointmentList;
	}

	@Override
	public String toString() {
		return "Director [directorId=" + directorId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", address=" + address + ", gender=" + gender + ", email=" + email + ", password=" + password
				+ ", contact=" + contact + ", date=" + date + ", isVerified=" + isVerified + "]";
	}

}
