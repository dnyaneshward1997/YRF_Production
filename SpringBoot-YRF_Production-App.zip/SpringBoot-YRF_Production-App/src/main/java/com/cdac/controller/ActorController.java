package com.cdac.controller;

import java.rmi.ServerException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.model.Actor;
import com.cdac.service.ActorService;

@RestController
@RequestMapping("/Actor")
@CrossOrigin
public class ActorController {

	@Autowired
	private ActorService actorService;

	// API to post data to database
	@PostMapping("/actorRegistration")
	public Actor addResource(@RequestBody Actor actor) {
		String actorPassword = actor.getPassword();
		actor.setPassword(actorPassword);
		actor.setEmail(actor.getEmail().toLowerCase());

		Actor actor1 = null;

		if (!actorService.findByEmail((actor.getEmail()))) {
			actor1 = actorService.addActor(actor);
		}

		System.out.println(actor1);
		return actor1;
	}

	// API to post data to database
	@PostMapping("/actorLogin")
	public ResponseEntity<?> showLoginForm(@RequestBody Actor actor) {

		System.out.println(actor.getEmail());
		System.out.println(actor.getPassword());

		// String directorPassword = director.getPassword();

		return new ResponseEntity<>(actorService.authenticateActor(actor.getEmail().toLowerCase(), actor.getPassword()),
				HttpStatus.OK);

	}

	// API to patch data to database
	@PatchMapping("/actorForgotPassword")
	public ResponseEntity<?> actorForgotPassword(@RequestBody Actor actor) {
		System.out.println(actor.getEmail());
		System.out.println(actor.getContact());
		return new ResponseEntity<>(actorService.authenticatePassword(actor), HttpStatus.CREATED);

	}

	// API to get data to database
	@GetMapping("/actorList")
	public List<Actor> showActorList() {

		return actorService.showAllActors(1);
	}

	@GetMapping("/findActorByActorIndustry/{actorIndustry}")
	public List<Actor> getActorByActorIndustry(@PathVariable String actorIndustry) {
		System.out.println(actorIndustry);
		return actorService.findActorByActorIndustry(actorIndustry);
	}

	@GetMapping("/findActor/{email}")
	public Actor findActor(@PathVariable String email) {
		return actorService.findActor(email);
	}

	@GetMapping("/findActorByEmail/{email}")
	public List<Actor> findActorByEmail(@PathVariable String email) {
		System.out.println(email);
		List<Actor> actorList = Arrays.asList(actorService.findActor(email));
		return actorList;
	}

	@GetMapping("/findActorVerificationList")
	public List<Actor> getActorVerificationList() {

		return actorService.showAllActors(0);
	}

	@GetMapping("/findActorVerificationListByEmail/{email}") // Checked
	public List<Actor> getActorVerificationListByEmail(@PathVariable String email) {

		return actorService.showVerificationListByEmail(email);
	}

	@PutMapping("/updateActor")
	public ResponseEntity<Actor> updateActor(@RequestBody Actor actor) throws ServerException {
		System.out.println(actor.getEmail());

		return new ResponseEntity<>(actorService.updateActorDetails(actor), HttpStatus.CREATED);
	}

	@PatchMapping("/findActorVerification/{id}")
	public int getDoctorVerification(@PathVariable long id) throws ServerException {

		return actorService.actorVerification(id);
	}

	@DeleteMapping("/deleteActorById/{id}")
	public int deleteActor(@PathVariable long id) throws ServerException {

		return actorService.deleteActor(id);

	}

	@DeleteMapping("/deleteActorVerificationById/{id}")
	public long deleteActorVerificationById(@PathVariable long id) throws ServerException {

		return actorService.deleteActorVerification(id);

	}

}
