package com.cdac.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.model.EmailDetails;
import com.cdac.service.EmailService;

@RestController
@RequestMapping("/Email")
@CrossOrigin
public class EmailController {

	@Autowired
	private EmailService emailService;

	// Sending a simple Email
	@PostMapping("/sendMail")
	public String sendMail(@RequestBody EmailDetails details) {
		System.out.println(details.toString());
		System.out.println(details.getRecipient());
		String status = emailService.sendSimpleMail(details);

		return status;
	}

}
