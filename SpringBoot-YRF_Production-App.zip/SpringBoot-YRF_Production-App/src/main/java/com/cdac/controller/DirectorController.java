package com.cdac.controller;

import java.rmi.ServerException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.model.Director;
import com.cdac.service.DirectorService;

@RestController
@RequestMapping("/Director")
@CrossOrigin
public class DirectorController {

	@Autowired
	private DirectorService directorService;

	// API to post data to database
	@PostMapping("/directorRegistration")
	public Director showRegistrationForm(@RequestBody Director director) {

		String directorPassword = director.getPassword();
		System.out.println(director.getContact());
		director.setPassword(directorPassword);
		director.setEmail(director.getEmail().toLowerCase());

		Director director1 = null;
		if (!directorService.findByEmail((director.getEmail()))) {
			director1 = directorService.addDirector(director);
		}
		System.out.println(director1);
		return director1;

	}

	// API to post data to database
	@PostMapping("/directorLogin")
	public ResponseEntity<?> showLoginForm(@RequestBody Director director) {

		System.out.println(director.getEmail());
		System.out.println(director.getPassword());

		// String directorPassword = director.getPassword();

		return new ResponseEntity<>(
				directorService.authenticateDirector(director.getEmail().toLowerCase(), director.getPassword()),
				HttpStatus.OK);

	}

	// API to patch data to database
	@PatchMapping("/directorForgotPassword")
	public ResponseEntity<?> directorForgotPassword(@RequestBody Director director) {

		System.out.println(director.getEmail());
		System.out.println(director.getContact());
		return new ResponseEntity<>(directorService.authenticatePassword(director), HttpStatus.CREATED);

	}

	// API to get data to database
	@GetMapping("/directorList")
	public List<Director> showDirectorList() {

		return directorService.showAllDirectors();
	}

	@GetMapping("/findDirectorByEmail/{email}")
	public List<Director> getDirectorByEmail(@PathVariable String email) {
		System.out.println(email);
		List<Director> directorList = Arrays.asList(directorService.findDirector(email));
		return directorList;
	}

	@GetMapping("/findDirectorByDirectorId/{id}")
	public Director getDirectorByDirectorId(@PathVariable long id) {
		System.out.println(id);
		return directorService.findDirectorByDirectorId(id);
	}

	// API to update data to database
	@PutMapping("/directorUpdate")
	public ResponseEntity<Director> updateDirector(@RequestBody Director director) throws ServerException {
		System.out.println(director.getEmail());
		System.out.println(director.getContact());

		return new ResponseEntity<>(directorService.updateDirectorDetails(director), HttpStatus.CREATED);
	}

	// API to delete data to database
	@DeleteMapping("/deleteDirector/{id}")
	public int deleteDirector(@PathVariable long id) throws ServerException {

		return directorService.deleteDirector(id);

	}

}
