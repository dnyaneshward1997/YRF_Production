package com.cdac.controller;

import java.sql.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.model.Actor;
import com.cdac.model.Appointment;
import com.cdac.model.Director;
import com.cdac.service.ActorService;
import com.cdac.service.AppointmentService;
import com.cdac.service.DirectorService;



@RestController
@RequestMapping("/Appointment")
@CrossOrigin
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;

	@Autowired
	private ActorService actorService;

	@Autowired
	private DirectorService directorService;

	
	@PostMapping("/bookAppointment")
	public Appointment showRegistrationForm(@RequestBody Appointment appointment) {
		System.out.println(appointment + "Line no 31");
		// System.out.println(a.getPatient()+"Line no 31");
		System.out.println(appointment.getTimeSlot() + "Line no 31");
		
		Director director1 = directorService.findDirector(appointment.getDirectorEmail());
		appointment.setDirector(director1);
		
		Actor actor1 = actorService.findActor(appointment.getActorEmail());
		appointment.setActor(actor1);


		return appointmentService.addAppointment(appointment);

	}

	
	@GetMapping("/showDateAndTimeslot/{appointmentDate}/{id}")
	List<Appointment> findTimeslot(@PathVariable Date appointmentDate, @PathVariable long id) {
		return appointmentService.findByDateAndAppoinmtmentId(appointmentDate, id);
	}

	
	@GetMapping("/getDirectorHistory/{email}")
	public List<Appointment> getDirectorHistory(@PathVariable String email) {

		return appointmentService.getDirectorHistory(email);
	}

	
	@GetMapping("/getAppointmentHistory")
	public List<Appointment> getAppointmentHistory() {

		return appointmentService.showAllAppointment();
	}

	
	@GetMapping("/getActorAppointmentList/{email}")
	public List<Appointment> getActorAppointmentList(@PathVariable String email) {

		return appointmentService.getActorAppointmentList(email);
	}

	@GetMapping("/getAppointmentListByActorEmail/{email}")
	public List<Appointment> getAppointmentListByActorEmail(@PathVariable String email) {

		System.out.println("hiii Actor");
		System.out.println("hiii Actor" + email);
		return appointmentService.getAppointmentListByActorEmail(email);
	}

	@GetMapping("/getActorHistory/{email}")
	public List<Appointment> getDocHistory(@PathVariable String email) {

		return appointmentService.getActorHistory(email);
	}

	@PatchMapping("/changeAppointmentStatus/{id}/{status}")
	public int changeAppointmentStatus(@PathVariable long id, @PathVariable int status) {

		return appointmentService.changeAppointmentStatus(id, status);
	}

}
