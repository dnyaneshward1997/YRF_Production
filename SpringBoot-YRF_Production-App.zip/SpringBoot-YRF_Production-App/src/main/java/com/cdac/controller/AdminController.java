package com.cdac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.model.Admin;
import com.cdac.service.AdminService;

@RestController
@RequestMapping("/Admin")
@CrossOrigin
public class AdminController {

	@Autowired
	private AdminService adminService;

	@PostMapping("/adminLogin")
	public ResponseEntity<?> authenticateAdmin(@RequestBody Admin admin) {
		System.out.println(admin);
	
		return new ResponseEntity<>(
				adminService.authenticateAdmin(admin.getEmail(), admin.getPassword()),
				HttpStatus.OK);
	}
}
