package com.cdac.dao;

import java.sql.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdac.model.Appointment;

@Repository
public interface AppointmentDao extends JpaRepository<Appointment, Long> {

	@Transactional
	@org.springframework.data.jpa.repository.Modifying
	@org.springframework.data.jpa.repository.Query("select a from Appointment a where a.appointmentDate = :DATE and a.actor.actorId = :id")
	List<Appointment> findByAppointmentDateAndActorId(@Param("DATE") Date appointmentDate, @Param("id") long id);

	@Transactional
	@org.springframework.data.jpa.repository.Modifying
	@org.springframework.data.jpa.repository.Query("select a from Appointment a where a.directorEmail = :email and a.director.isVerified = true")
	List<Appointment> findAllByDirectorEmail(@Param("email") String email);

	@Transactional
	@org.springframework.data.jpa.repository.Modifying
	@org.springframework.data.jpa.repository.Query("select a from Appointment a where a.directorEmail = :email and a.actor.isVerified = 1 and a.status != 2")
	List<Appointment> findAllByActorAppointmentHistory(@Param("email") String email);

	List<Appointment> findAllByActorEmailAndStatus(String email, int status);

	List<Appointment> findAllByActorEmail(String email);

	@Transactional
	@org.springframework.data.jpa.repository.Modifying
	@org.springframework.data.jpa.repository.Query("update Appointment a set a.status = :Status where a.appointmentId = :id")
	int AppointmentStatus(@Param("id") long id, @Param("Status") int Status);

}
