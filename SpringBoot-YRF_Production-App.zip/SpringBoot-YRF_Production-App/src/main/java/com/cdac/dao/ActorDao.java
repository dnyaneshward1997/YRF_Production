package com.cdac.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdac.model.Actor;

@Repository
public interface ActorDao extends JpaRepository<Actor, Long> {

	Actor findByEmailAndIsVerified(String string, int verified);

	List<Actor> findAllByActorIndustryAndIsVerified(String actorIndustry, int verified);

	Actor findByEmailAndPasswordAndIsVerified(String email, String password, int verified);

	Actor findByEmailAndContactAndIsVerified(String email, long contact, int verified);

	List<Actor> findAllByIsVerified(int verified);

	@Transactional
	@org.springframework.data.jpa.repository.Modifying
	@org.springframework.data.jpa.repository.Query("update Actor a set a.isVerified = 2 where a.actorId = :id")
	int deleteActor(@Param("id") long id);

	@Transactional
	@org.springframework.data.jpa.repository.Modifying
	@org.springframework.data.jpa.repository.Query("update Actor a set a.isVerified = 1 where a.actorId = :id")
	int actorVerified(@Param("id") long id);
}
