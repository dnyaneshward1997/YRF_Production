package com.cdac.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdac.model.Director;


@Repository
public interface DirectorDao extends JpaRepository<Director, Long> {

	Director findByEmailAndIsVerified(String email, boolean verified);

	Director findByDirectorId(long id);

	Director findByEmailAndPasswordAndIsVerified(String email, String password, boolean verified);

	Director findByEmailAndContactAndIsVerified(String email, String contact, boolean verified);

	List<Director> findAllByIsVerified(boolean verified);

	
	@Transactional
	@org.springframework.data.jpa.repository.Modifying
	@org.springframework.data.jpa.repository.Query("update Director d set d.isVerified = false where d.directorId = :id")
	int deleteDirector(@Param("id") long id);

}
