package com.cdac.service;

import java.util.List;
import com.cdac.model.Director;

public interface DirectorService {
	
	Director addDirector(Director director);

	Director saveDirector(Director newUser);

	boolean findByEmail(String string);

	Director authenticateDirector(String email, String password);
	
	Director authenticatePassword(Director director);
	
	List<Director> showAllDirectors();
	
	int deleteDirector(long id);
	
	Director findDirector(String email);
	
	Director findDirectorByDirectorId (long id);
	
	Director updateDirectorDetails(Director director);

}
