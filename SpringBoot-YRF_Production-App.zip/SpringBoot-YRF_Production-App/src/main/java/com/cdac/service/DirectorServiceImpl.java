package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.DirectorDao;
import com.cdac.model.Director;

@Service
public class DirectorServiceImpl implements DirectorService {

	@Autowired
	private DirectorDao directorDao;

	@Override
	public Director addDirector(Director director) {
		// TODO Auto-generated method stub
		Director director1 = null;
		try {
			director1 = directorDao.save(director);
			return director1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return director1;
	}

	@Override
	public Director saveDirector(Director newUser) {
		// TODO Auto-generated method stub
		return directorDao.save(newUser);
	}

	@Override
	public boolean findByEmail(String email) {
		// TODO Auto-generated method stub
		Director director1 = directorDao.findByEmailAndIsVerified(email, true);

		if (director1 != null) {
			return true;
		}
		return false;
	}

	@Override
	public Director authenticateDirector(String email, String password) {
		// TODO Auto-generated method stub
		return directorDao.findByEmailAndPasswordAndIsVerified(email, password, true);
	}

	@Override
	public Director authenticatePassword(Director director) {
		// TODO Auto-generated method stub
		String directorPassword = director.getPassword();

		Director director1 = directorDao.findByEmailAndContactAndIsVerified(director.getEmail().toLowerCase(),
				director.getContact(), true);

		if (director1 != null) {
			director1.setPassword(directorPassword);
			directorDao.save(director);
			return director1;
		}

		return null;
	}

	@Override
	public List<Director> showAllDirectors() {
		// TODO Auto-generated method stub
		return directorDao.findAllByIsVerified(true);
	}

	@Override
	public int deleteDirector(long id) {
		// TODO Auto-generated method stub
		try {
			return directorDao.deleteDirector(id);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public Director findDirector(String email) {
		// TODO Auto-generated method stub
		return directorDao.findByEmailAndIsVerified(email, true);
	}

	@Override
	public Director findDirectorByDirectorId(long id) {
		// TODO Auto-generated method stub
		return directorDao.findByDirectorId(id);
	}

	@Override
	public Director updateDirectorDetails(Director director) {
		// TODO Auto-generated method stub

		Director director1 = findDirectorByDirectorId(director.getDirectorId());
		System.out.println(director.getEmail());

		if (director1.getEmail().equalsIgnoreCase(director.getEmail().toLowerCase())) {
			directorDao.save(director);
			return director;
		} else if ((directorDao.findByEmailAndIsVerified(director.getEmail(), true)) != null) {
			return null;
		} else {
			directorDao.save(director);
			return director;
		}

	}

}
