package com.cdac.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.ActorDao;
import com.cdac.model.Actor;

@Service
public class ActorServiceImpl implements ActorService {

	@Autowired
	private ActorDao actorDao;

	@Override
	public Actor addActor(Actor actor) {
		// TODO Auto-generated method stub
		Actor actor1 = null;

		try {
			actor1 = actorDao.save(actor);
			return actor1;
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return actor1;
	}

	@Override
	public Actor saveActor(Actor newUser) {
		// TODO Auto-generated method stub
		return actorDao.save(newUser);
	}

	@Override
	public boolean findByEmail(String email) {
		// TODO Auto-generated method stub
		Actor actor1 = actorDao.findByEmailAndIsVerified(email, 1);

		if (actor1 != null) {
			return true;
		}
		return false;
	}

	@Override
	public List<Actor> findActorByActorIndustry(String actorIndustry) {
		// TODO Auto-generated method stub
		return actorDao.findAllByActorIndustryAndIsVerified(actorIndustry, 1);
	}

	@Override
	public Actor authenticateActor(String email, String password) {
		// TODO Auto-generated method stub
		Actor actor1 = actorDao.findByEmailAndPasswordAndIsVerified(email, password, 1);
		System.out.println(actor1);
		return actor1;
	}

	@Override
	public Actor authenticatePassword(Actor actor) {
		// TODO Auto-generated method stub

		Actor actor1 = actorDao.findByEmailAndContactAndIsVerified(actor.getEmail().toLowerCase(), actor.getContact(),
				1);

		if (actor1 != null) {
			actor1.setPassword(actor.getPassword());
			actorDao.save(actor1);
			return actor1;
		}
		return null;
	}

	@Override
	public Actor findActor(String email) {
		// TODO Auto-generated method stub
		return actorDao.findByEmailAndIsVerified(email, 1);
	}

	@Override
	public int deleteActor(long id) {
		// TODO Auto-generated method stub
		try {
			return actorDao.deleteActor(id);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return 0;
		}
	}

	@Override
	public List<Actor> showAllActors(int verified) {
		// TODO Auto-generated method stub
		return actorDao.findAllByIsVerified(verified);
	}

	@Override
	public Actor updateActorDetails(Actor actor) {
		// TODO Auto-generated method stub
		Actor actor1 = findActor(actor.getEmail());

		System.out.println(actor1.getEmail());

		if (actor1.getEmail().equalsIgnoreCase(actor.getEmail().toLowerCase())) {

			actorDao.save(actor);
			return actor;

		} else if ((actorDao.findByEmailAndIsVerified(actor.getEmail(), 1)) != null) {
			return null;

		} else {
			actorDao.save(actor);
			return actor;
		}
	}

	@Override
	public int actorVerification(long id) {
		// TODO Auto-generated method stub
		try {
			return actorDao.actorVerified(id);

		} catch (Exception e) {
			System.out.println(e.getMessage());
			return 0;
		}
	}

	@Override
	public long deleteActorVerification(long id) {
		// TODO Auto-generated method stub
		try {
			actorDao.deleteById(id);
			return id;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return -1;
		}

	}

	@Override
	public List<Actor> showVerificationListByEmail(String email) {
		// TODO Auto-generated method stub
		List<Actor> actorList = Arrays.asList(actorDao.findByEmailAndIsVerified(email, 1));

		return actorList;
	}
}
