package com.cdac.service;

import java.util.List;

import com.cdac.model.Actor;

public interface ActorService {

	public Actor addActor(Actor actor);

	Actor saveActor(Actor newUser);

	boolean findByEmail(String string);

	public List<Actor> findActorByActorIndustry(String actorIndustry);

	Actor authenticateActor(String email, String password);

	public Actor authenticatePassword(Actor actor);

	public Actor findActor(String email);

	int deleteActor(long id);

	List<Actor> showAllActors(int verified);

	Actor updateActorDetails(Actor actor);

	int actorVerification(long id);

	long deleteActorVerification(long id);

	List<Actor> showVerificationListByEmail(String email);

}
