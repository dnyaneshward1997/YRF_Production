package com.cdac.service;

import org.springframework.stereotype.Service;

import com.cdac.model.Admin;

@Service
public interface AdminService {

	public Admin authenticateAdmin(String email, String password);

}
