package com.cdac.service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.AppointmentDao;
import com.cdac.model.Appointment;

@Service
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	private AppointmentDao appointmentDao;

	@Override
	public Appointment addAppointment(Appointment appointment) {
		// TODO Auto-generated method stub
		if (appointment.getTimeSlot() == 0) {

			return null;
		} else {
			return appointmentDao.save(appointment);
		}
	}

	@Override
	public List<Appointment> findByDateAndAppoinmtmentId(Date appointmentDate, long id) {
		// TODO Auto-generated method stub
		return appointmentDao.findByAppointmentDateAndActorId(appointmentDate, id);
	}

	@Override
	public List<Appointment> getDirectorHistory(String email) {
		// TODO Auto-generated method stub
		return appointmentDao.findAllByDirectorEmail(email);
	}

	@Override
	public List<Appointment> getActorHistory(String email) {
		// TODO Auto-generated method stub
		return appointmentDao.findAllByActorAppointmentHistory(email);
	}

	@Override
	public List<Appointment> getActorAppointmentList(String email) {
		// TODO Auto-generated method stub
		return appointmentDao.findAllByActorEmailAndStatus(email, 2);
	}

	@Override
	public List<Appointment> getAppointmentListByActorEmail(String email) {
		// TODO Auto-generated method stub
		return appointmentDao.findAllByActorEmail(email);
	}

	@Override
	public int changeAppointmentStatus(long id, int status) {
		// TODO Auto-generated method stub
		return appointmentDao.AppointmentStatus(id, status);
	}

	@Override
	public List<Appointment> showAllAppointment() {

		return appointmentDao.findAll();

	}

}
