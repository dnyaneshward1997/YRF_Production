package com.cdac.service;

import java.sql.Date;
import java.util.List;

import com.cdac.model.Appointment;


public interface AppointmentService {

	Appointment addAppointment(Appointment appointment);
	
	List<Appointment> findByDateAndAppoinmtmentId(Date appointmentDate, long id);
	
	List<Appointment> getDirectorHistory(String email);
	
	List<Appointment> showAllAppointment();
	
	List<Appointment> getActorHistory(String email);
	
	List<Appointment> getActorAppointmentList(String email);
	
	List<Appointment> getAppointmentListByActorEmail(String email);

    int changeAppointmentStatus(long id,int status);
}
