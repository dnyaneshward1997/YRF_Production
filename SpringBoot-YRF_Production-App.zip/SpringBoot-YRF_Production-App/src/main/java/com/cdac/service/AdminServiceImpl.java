package com.cdac.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.AdminDao;
import com.cdac.model.Admin;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDao adminDao;

	@Override
	public Admin authenticateAdmin(String email, String password) {
		// TODO Auto-generated method stub
		Admin admin = adminDao.findAdminByEmailAndPassword(email,  password);
		System.out.println(admin);
		return admin;
	}

}
