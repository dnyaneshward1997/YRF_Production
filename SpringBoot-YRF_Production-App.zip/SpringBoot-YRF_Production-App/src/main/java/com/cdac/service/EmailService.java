package com.cdac.service;

import com.cdac.model.EmailDetails;

public interface EmailService {
	
	  String sendSimpleMail(EmailDetails details);

}
